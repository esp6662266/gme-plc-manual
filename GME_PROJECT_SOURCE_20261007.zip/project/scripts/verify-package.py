from pathlib import Path
import hashlib, json, sys
root = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent)
manifest = json.loads((root/'SHA256SUMS.json').read_text(encoding='utf-8'))
errors = []
for item in manifest['files']:
    path = root/item['path']
    if not path.is_file():
        errors.append('MISSING '+item['path'])
    elif hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
        errors.append('CHANGED '+item['path'])
print(json.dumps({'checked':len(manifest['files']), 'errors':errors}, ensure_ascii=False))
sys.exit(1 if errors else 0)
