from pathlib import Path
from PIL import Image, ImageOps, ImageDraw
from html.parser import HTMLParser
import urllib.parse, json
from pypdf import PdfReader
base = Path(r'C:\Users\GME\Documents\Codex\2026-10-01\d')
out = base/'outputs/GME_manual_20261007'
qa = base/'tmp/gme_manual_qa'
pages = sorted(qa.glob('final2-page-*.png'))
for part in range(0, len(pages), 8):
    sheet = Image.new('RGB', (1600, 2200), '#dde4eb')
    draw = ImageDraw.Draw(sheet)
    for offset, page in enumerate(pages[part:part+8]):
        img = Image.open(page).convert('RGB')
        img.thumbnail((380, 1010))
        x, y = (offset%4)*400+(400-img.width)//2, (offset//4)*1100+35
        sheet.paste(img, (x,y))
        draw.text(((offset%4)*400+12, (offset//4)*1100+10), page.name, fill='#172b3f')
    sheet.save(qa/f'final2-contact-{part//8+1}.png')
class Links(HTMLParser):
    def __init__(self): super().__init__(); self.links=[]; self.ids=set()
    def handle_starttag(self, tag, attrs):
        attrs=dict(attrs)
        if 'id' in attrs: self.ids.add(attrs['id'])
        for key in ['href','src']:
            if key in attrs: self.links.append(attrs[key])
broken=[]
parsers={}
for file in out.glob('*.html'):
    parser=Links(); parser.feed(file.read_text(encoding='utf8')); parsers[file.name]=parser
for name, parser in parsers.items():
    for link in parser.links:
        url=urllib.parse.urlsplit(link)
        if url.scheme or url.netloc: continue
        target=out/urllib.parse.unquote(url.path) if url.path else out/name
        if not target.exists(): broken.append([name,link,'file'])
        elif url.fragment and target.name in parsers and url.fragment not in parsers[target.name].ids:
            broken.append([name,link,'anchor'])
pdf=PdfReader(out/'GME_HMI_PLC_manual.pdf')
text='\n'.join(page.extract_text() for page in pdf.pages)
chapters=[]
for line in (out/'manual.md').read_text(encoding='utf8').splitlines():
    if line.startswith('## '): chapters.append(line[3:])
stats={'pdf_pages':len(pdf.pages),'chapters':len(chapters),'broken_links':broken,'rendered_pages':len(pages),'pdf_korean_title':'GME HMI' in text}
(qa/'artifact_verification.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(stats,ensure_ascii=False))
assert len(chapters)==22 and len(pdf.pages)==31 and not broken and len(pages)==31
