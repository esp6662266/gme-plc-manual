from pathlib import Path
import csv
import html
import json
import math
import re
import shutil
import hashlib

from PIL import Image, ImageDraw, ImageFont
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak,
    Table, TableStyle, Image as PDFImage, KeepTogether,
)
from reportlab.platypus.tableofcontents import TableOfContents
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/GME_manual_20261007'
ASSETS = OUT / 'assets'
REF = OUT / 'references'
QA = ROOT / 'tmp/gme_manual_qa'
for folder in [ASSETS, REF, QA]:
    folder.mkdir(parents=True, exist_ok=True)
FONT = 'C:/Windows/Fonts/malgun.ttf'
BOLD = 'C:/Windows/Fonts/malgunbd.ttf'
NAVY = '#193854'
BLUE = '#eaf1f8'
TEAL = '#e7f2ef'
AMBER = '#fff2dc'
INK = '#142435'
GRAY = '#536273'


class Diagram:
    def __init__(self, name, title, subtitle, height=880):
        self.name, self.w, self.h = name, 1400, height
        self.im = Image.new('RGB', (self.w, self.h), 'white')
        self.d = ImageDraw.Draw(self.im)
        self.svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="1400" height="{height}" viewBox="0 0 1400 {height}">', '<rect width="100%" height="100%" fill="white"/>']
        self.text(45, 20, title, 38, INK, bold=True)
        self.text(45, 77, subtitle, 24, GRAY)

    def text(self, x, y, value, size=27, color=INK, bold=False):
        font = ImageFont.truetype(BOLD if bold else FONT, size)
        self.d.text((x, y), value, font=font, fill=color)
        self.svg.append(f'<text x="{x}" y="{y+size}" font-family="Malgun Gothic,sans-serif" font-size="{size}" font-weight="{"bold" if bold else "normal"}" fill="{color}">{html.escape(value)}</text>')

    def wrap(self, value, max_width, size):
        font = ImageFont.truetype(FONT, size)
        rows = []
        for source in value.split('\n'):
            current = ''
            for char in source:
                if current and self.d.textlength(current + char, font=font) > max_width:
                    rows.append(current.rstrip())
                    current = char.lstrip()
                else:
                    current += char
            rows.append(current)
        return rows

    def box(self, x, y, w, h, title, lines, fill=BLUE):
        self.d.rounded_rectangle((x, y, x+w, y+h), radius=10, fill=fill, outline='#b4c3d2', width=2)
        self.svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="{fill}" stroke="#b4c3d2" stroke-width="2"/>')
        title_size = 30
        while self.d.textlength(title, font=ImageFont.truetype(BOLD, title_size)) > w-34:
            title_size -= 1
        self.text(x+17, y+12, title, title_size, NAVY, True)
        rows = self.wrap('\n'.join(lines), w-34, 25)
        if 58+len(rows)*34 > h-12:
            raise ValueError(f'Diagram text overflow: {self.name} {title}: {rows}')
        for i, line in enumerate(rows):
            self.text(x+17, y+58+i*34, line, 25)

    def arrow(self, points, color=GRAY):
        self.d.line(points, fill=color, width=3)
        x, y = points[-1]
        px, py = points[-2]
        angle = math.atan2(y-py, x-px)
        pts = [(x,y), (x-14*math.cos(angle-.42),y-14*math.sin(angle-.42)), (x-14*math.cos(angle+.42),y-14*math.sin(angle+.42))]
        self.d.polygon(pts, fill=color)
        self.svg.append(f'<polyline points="{" ".join(f"{a},{b}" for a,b in points)}" fill="none" stroke="{color}" stroke-width="3"/>')
        self.svg.append(f'<polygon points="{" ".join(f"{a:.1f},{b:.1f}" for a,b in pts)}" fill="{color}"/>')

    def save(self, note):
        for i, line in enumerate(self.wrap(note, 1300, 23)):
            self.text(45, self.h-90+i*32, line, 23, GRAY)
        self.im.save(ASSETS/f'{self.name}.png')
        self.svg.append('</svg>')
        (ASSETS/f'{self.name}.svg').write_text('\n'.join(self.svg), encoding='utf-8')


def diagrams():
    g=Diagram('system_architecture', 'HMI와 PLC 및 이력 저장 구성', '현재 설정과 화면 및 백업에서 확인한 역할', 850)
    g.box(45,145,405,220,'운전 PC의 HMI',['InTouch WindowViewer','명령과 설정 요청','상태와 알람 표시'],TEAL)
    g.box(495,145,405,220,'운전 PC의 통신',['PLC Access Name / Topic','SuiteLink → SIDIR','OI.SIDIR 드라이버'])
    g.box(945,145,410,220,'물리 PLC',['CPU 1515-2 PN 참조','190.168.200.230 : 102','설비 제어와 I/O 처리'])
    g.arrow([(450,245),(495,245)]);g.arrow([(900,245),(945,245)])
    g.box(45,425,405,240,'알람 이력 경로',['Alarm DB Logger','wwalmlogger.exe','WWALMDB → Historical Alarms'],TEAL)
    g.box(495,425,405,240,'태그 이력 경로',['InTouch 트렌드 로그','HistData 접근','알람 DB와 다른 경로'])
    g.box(945,425,410,240,'작업용 가상 PC',['VMware GME_TIA','TIA Portal V18 / V19','프로젝트 열람과 편집'],AMBER)
    g.arrow([(250,365),(250,425)])
    g.save('구성 설명용 화살표다. PLC 온라인 프로그램 일치와 장치별 태그 품질은 추가 확인 대상이다. 10월 7일에는 유선 링크 단절이 관찰됐다.')

    g=Diagram('execution_structure','PLC 순환 실행과 주기 실행','백업의 Main 참조 순서와 TIA 화면의 OB 식별을 함께 정리',1080)
    steps=[('Main OB1의 HMI 연계',['Simulation 참조','Recipes / HMI / 입출력 워드']),('입력과 알람 판정',['Analog input conversion','Allarms 1 / 2 / 3']),('장치와 출력 처리',['Motors / Filter / R1 / Burner','Valve loop / Analog output']),('알람과 유지보수',['Allarm manager / 시간 관리','Main Network 14 / 15'])]
    for i,(title,lines) in enumerate(steps):
        y=145+i*204
        g.box(45,y,655,177,title,lines)
        if i<3:g.arrow([(370,y+177),(370,y+204)])
    g.box(770,145,585,202,'OB32의 1초 처리',['TC01 / TC02 선택과 버너 PID','자동 순차 운전 블록 호출'],AMBER)
    g.box(770,390,585,236,'OB35의 100ms 처리',['RO01 / PC01 / TC03 제어','MV05 / MV02 / MV01 / VT02','공기와 가스 비율 계산'],AMBER)
    g.box(770,670,585,255,'기동 및 이벤트 처리',['OB100 기본 상태 초기화','OB34 200ms 시험 참조','OB82 / 86 / 121 / 122 / 10'])
    g.save('주기 OB는 Main과 별도로 실행된다. 실제 호출 조건, 주기와 우선순위는 원본 네트워크 및 OB 속성에서 확인한다.')

    g=Diagram('pv01_diagnostics','PV01 명령과 위치 피드백 진단','현재 신호 경로의 점검 항목과 두 번 실패 처리의 개선 제안',980)
    g.box(45,145,390,218,'명령과 허가',['HMI 또는 자동 단계 요청','A / B와 열림 / 닫힘 구분','인터록과 현재 위치 확인'])
    g.box(505,145,390,218,'출력과 현장 동작',['A Q5.2 / B Q5.3 참조','밸브 전압과 실제 움직임','출력 극성은 추가 확인'])
    g.box(965,145,390,218,'위치 피드백',['A I8.6 / I8.7 참조','B I9.0 / I9.1 참조','원시 입력과 DB11 상태'])
    g.arrow([(435,250),(505,250)]);g.arrow([(895,250),(965,250)])
    g.box(45,430,600,165,'정상 완료',['목표 리미트 안정 확인','명령 완료와 단계 진행'],TEAL)
    g.box(755,430,600,165,'현재 고장 판정 참조',['A S5T#4s / B S5T#7s','정확한 조건은 LAD 확인'],AMBER)
    g.arrow([(1150,363),(1150,430)])
    g.box(45,660,600,188,'개선 제안 첫 실패',['명령당 한 번만 카운트','SafeHold와 다음 단계 보류','조건 확인 후 재시도 허가'],TEAL)
    g.box(755,660,600,188,'개선 제안 두 번째 실패',['최종 알람과 동작 잠금','첫 실패부터 진단 기록','A/B 방향별 정책 정의'],AMBER)
    g.arrow([(645,755),(755,755)])
    g.save('실패를 PLC 스캔마다 세면 안 된다. 보호 정지·비상정지·가스·화염 관련 기능에 이 재시도 정책을 일괄 적용하지 않는다.')

    g=Diagram('maintenance_logic','유지보수 기간 제한 알람의 Set와 Reset','2월 프로젝트 Main Network 14와 15의 화면 확인을 바탕으로 설명',1010)
    g.box(45,145,600,185,'Network 14의 코드 비교',['DB1.DBW288과 비교 상수','일치하면 날짜 검사 건너뜀','불일치하면 CPU 날짜 읽기'])
    g.box(755,145,600,185,'CPU 날짜 검사',['RD_SYS_T → T_CONV','날짜 2026-01-01 이상','DB3.DBX7.6 Set'])
    g.arrow([(645,240),(755,240)])
    g.box(45,410,1310,184,'Network 15의 Reset 경로',['ON M0.0 + Flag.RESET_ALLARM DB2.DBX6.0 + 알람 DB3.DBX7.6','직렬 조건이 성립하면 같은 알람 비트를 Reset','HMI Reset 요청 DB2.DBX13.4는 내부 Reset과 구분'])
    g.arrow([(1050,330),(1050,410)])
    g.box(45,680,600,186,'원인 조건이 계속 남음',['Reset 요청이 끝난 뒤','Network 14에서 다시 Set','09:15 복귀 후 1.11초 재발'],AMBER)
    g.box(755,680,600,186,'추가 확인',['실제 CPU 날짜와 코드 값','HMI 항목 주소와 전달 경로','제작사 절차와 운전 영향'],TEAL)
    g.arrow([(350,594),(350,680)])
    g.save('CPU 시각이 기준이다. PC 시간을 바꾸거나 날짜 상수를 연장하는 작업은 이번 점검에서 수행하지 않았다.')

    g=Diagram('improvement_architecture','기존 HMI 주소를 유지하는 구조 개선','구현되지 않은 설계 제안이며 별도 복사본과 시험에서 검토',1000)
    g.box(45,145,600,176,'현장 입력 정규화',['원시 I/O와 품질을 수집','스케일·필터·모순 상태 정의'])
    g.box(755,145,600,176,'보호 및 운전 허가',['조건별 허가와 거부 이유','전용 보호 회로 경계 확인'],AMBER)
    g.box(45,400,600,190,'장치별 기능 블록',['모터 / 밸브 / 게이트 상태','명령 번호·완료·실패 원인','타임아웃과 Reset 정책'])
    g.box(755,400,600,190,'공정 순서 상태 관리',['진입 동작·완료 조건','제한 시간·실패 이유','준비 상태와 실제 피드백'])
    g.arrow([(350,321),(350,400)]);g.arrow([(1050,321),(1050,400)]);g.arrow([(645,495),(755,495)])
    g.box(45,680,600,188,'기존 HMI 호환 계층',['기존 DB 오프셋 보존','새 구조에서 기존 주소로 변환','화면 태그 영향 검증'],TEAL)
    g.box(755,680,600,188,'진단과 이력 계층',['명령과 결과의 사건 기록','첫 실패·알람·저장 상태','변경 이력과 시험 증거'],TEAL)
    g.arrow([(350,590),(350,680)]);g.arrow([(1050,590),(1050,680)])
    g.save('새 DB와 변환 블록을 검토한다. 기존 DB 멤버의 재배치·최적화 변경은 HMI 통신 주소와 함께 검증해야 한다.')


def write_csv(name, headers, rows):
    with (REF/name).open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(headers);writer.writerows(rows)


def references(md):
    blocks=json.loads((ROOT/'outputs/PLC_review/block_summary.json').read_text('utf-8'))
    old=list(csv.DictReader((ROOT/'outputs/PLC_review/PLC_블록목록.csv').open(encoding='utf-8-sig')))
    write_csv('blocks.csv',list(old[0])+['근거'],[list(x.values())+['6월 백업 검색 색인; 현재 PLC와 일치 미확인'] for x in old])
    rows=[]
    for b in blocks:
        for i,n in enumerate(b['networks'],1):
            code=' | '.join(f'{k}: {v}' for k,v in n.items() if k in ['LADFBD Code','STL Code','SCL Code'])
            rows.append([b['name'],i,n.get('Network title',''),n['segment'],n['doc'],code,'색인 순서 및 토큰; 실제 접점·구문 복원 아님'])
    write_csv('networks.csv',['블록명','색인 내 순서','네트워크 제목','색인 세그먼트','색인 문서','검색 토큰','근거와 한계'],rows)
    hmi=Path('C:/Users/Public/Wonderware/InTouch Applications/GianniMoriEngineering_2025_rev1')
    windows=json.loads((hmi/'WindowsInfo.json').read_text('utf-8-sig'))
    windows=[x for x in windows if not x.get('IsFolder') and not x.get('IsScript') and x.get('FolderType')==-1 and x.get('ScriptType')==0]
    write_csv('hmi_windows.csv',['화면 이름','ID','Parent ID','설명','근거와 한계'],[[x['Name'],x['Id'],x['ParentId'],x.get('Description',''),'WindowsInfo.json; 메뉴 노출 여부 미확인'] for x in windows])
    tags=[]; source=''
    for line in (hmi/'dde.cfg').read_text('utf-8-sig',errors='replace').splitlines():
        match=re.match(r'\s*Source Name:\s*(.+)',line)
        if match:source=match.group(1).strip()
        match=re.match(r'\s*(.+?);([0-9A-F]+):\s*(.+)',line)
        if match and source=='PLC':
            tags.append([match.group(1),match.group(3).strip(),source,match.group(2),'dde.cfg 설정; 온라인 현재값 아님'])
    write_csv('hmi_plc_tags.csv',['HMI 태그','설정 주소','Access Name','태그 내부 ID','근거와 한계'],tags)
    checks=[]
    for line in md.splitlines():
        if re.match(r'\| V\d\d \|',line):
            checks.append([x.strip() for x in line.strip('|').split('|')]+['미확인'])
    write_csv('verification.csv',['번호','확인 과제','필요한 증거','연결되는 개선','상태'],checks)
    return dict(blocks=len(blocks),networks=len(rows),hmi_tags=len(tags),hmi_windows=len(windows),verification=len(checks))


def inline(value):
    value=html.escape(value)
    value=re.sub(r'!\[([^]]*)\]\(([^)]+)\)',r'\1',value)
    value=re.sub(r'\[([^]]+)\]\(([^)]+)\)',lambda m: f'<link href="{m[2]}" color="#193854">{m[1]}</link>' if m[2].startswith('https://') else m[1],value)
    value=re.sub(r'`([^`]+)`',r'<font face="Malgun">\1</font>',value)
    value=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',value)
    return value


def parse_md(md):
    lines=md.splitlines();i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line:i+=1;continue
        if line.startswith('```'):
            code=[];i+=1
            while i<len(lines) and not lines[i].startswith('```'):code.append(lines[i]);i+=1
            i+=1;yield ('code','\n'.join(code));continue
        if line.startswith('|') and i+1<len(lines) and re.match(r'^\|[\s:|\-]+\|$',lines[i+1].strip()):
            table=[[x.strip() for x in line.strip('|').split('|')]];i+=2
            while i<len(lines) and lines[i].strip().startswith('|'):
                table.append([x.strip() for x in lines[i].strip().strip('|').split('|')]);i+=1
            yield ('table',table);continue
        m=re.match(r'^(#{1,3})\s+(.+)',line)
        if m:yield (f'h{len(m[1])}',m[2]);i+=1;continue
        m=re.match(r'^!\[([^]]*)\]\(([^)]+)\)',line)
        if m:yield ('image',(m[1],m[2]));i+=1;continue
        m=re.match(r'^(\d+\.|-)\s+(.+)',line)
        if m:yield ('list',line);i+=1;continue
        para=[line];i+=1
        while i<len(lines) and lines[i].strip() and not re.match(r'^(#|\||```|!\[|\d+\.\s|-\s)',lines[i].strip()):
            para.append(lines[i].strip());i+=1
        yield ('p',' '.join(para))


class ManualDoc(BaseDocTemplate):
    def __init__(self,path):
        super().__init__(str(path),pagesize=A4,leftMargin=43,rightMargin=43,topMargin=45,bottomMargin=42,title='GME HMI와 PLC 운전 및 구조 개선 매뉴얼',author='GME 설비 기술 문서',pageCompression=1)
        self.addPageTemplates(PageTemplate(id='manual',frames=Frame(self.leftMargin,self.bottomMargin,self.width,self.height,id='body'),onPage=self.page_frame))

    def page_frame(self,canvas,doc):
        canvas.saveState();canvas.setFont('Malgun',8);canvas.setFillColor(colors.HexColor(GRAY))
        canvas.drawString(43,A4[1]-28,'GME HMI와 PLC 운전 및 구조 개선 매뉴얼')
        canvas.drawRightString(A4[0]-43,A4[1]-28,'2026년 10월 7일  /  v1.0')
        canvas.drawString(43,24,'관찰 자료와 백업 분석을 구분하여 사용')
        canvas.drawRightString(A4[0]-43,24,str(doc.page));canvas.restoreState()

    def afterFlowable(self,flowable):
        if isinstance(flowable,Paragraph) and flowable.style.name=='Chapter' and re.match(r'^\d+ ',flowable.getPlainText()):
            title=flowable.getPlainText();key='chapter-'+title.split()[0]
            self.canv.bookmarkPage(key);self.canv.addOutlineEntry(title,key,0,False)
            self.notify('TOCEntry',(0,title,self.page,key))


def make_pdf(md):
    pdfmetrics.registerFont(TTFont('Malgun',FONT))
    pdfmetrics.registerFont(TTFont('MalgunBold',BOLD))
    pdfmetrics.registerFontFamily('Malgun',normal='Malgun',bold='MalgunBold',italic='Malgun',boldItalic='MalgunBold')
    body=ParagraphStyle('Body',fontName='Malgun',fontSize=10.2,leading=16.4,wordWrap='CJK',spaceAfter=8,textColor=colors.HexColor(INK))
    title=ParagraphStyle('Title',parent=body,fontName='MalgunBold',fontSize=25,leading=36,spaceBefore=40,spaceAfter=24)
    chapter=ParagraphStyle('Chapter',parent=body,fontName='MalgunBold',fontSize=16,leading=24,spaceBefore=18,spaceAfter=12,keepWithNext=True)
    sub=ParagraphStyle('Subhead',parent=body,fontName='MalgunBold',fontSize=12,leading=19,spaceBefore=12,spaceAfter=7,keepWithNext=True)
    cell=ParagraphStyle('Cell',parent=body,fontSize=9.1,leading=14,spaceAfter=0)
    head=ParagraphStyle('TableHeader',parent=cell,fontName='MalgunBold',textColor=colors.white)
    code=ParagraphStyle('Code',parent=body,fontSize=8.9,leading=14,leftIndent=9,rightIndent=9,spaceBefore=6,spaceAfter=10)
    caption=ParagraphStyle('Caption',parent=body,fontSize=9,leading=14,textColor=colors.HexColor(GRAY),spaceAfter=12)
    doc=ManualDoc(OUT/'GME_HMI_PLC_manual.pdf');story=[];parsed=list(parse_md(md));body_start=next(i for i,x in enumerate(parsed) if x[0]=='h2')
    for kind,value in parsed[:body_start]:
        if kind=='h1':story.append(Paragraph(inline(value),title))
        elif kind=='p':story.append(Paragraph(inline(value),body))
    story.append(Spacer(1,14));story.append(Paragraph('읽는 순서',sub))
    story.append(Paragraph('운전 화면은 2장과 3장, PV01은 8장, 알람 이력은 10장, 유지보수 제한은 11장, 백업은 15장, 구조 개선은 16장부터 20장까지 읽는다. 상세 검색은 함께 제공한 HTML과 CSV를 사용한다.',body))
    story.append(PageBreak());story.append(Paragraph('목차',chapter))
    toc=TableOfContents();toc.levelStyles=[ParagraphStyle('TOC',parent=body,fontSize=10.0,leading=16.5,spaceBefore=3,spaceAfter=0)]
    story.extend([toc,PageBreak()])
    skip_image=False
    for idx,(kind,value) in enumerate(parsed[body_start:],body_start):
        if kind=='h2' and idx+1<len(parsed) and parsed[idx+1][0]=='image':
            label,image_ref=parsed[idx+1][1];image_path=OUT/image_ref
            im=Image.open(image_path);w=doc.width-12;h=w*im.height/im.width
            story.append(KeepTogether([Paragraph(inline(value),chapter),PDFImage(str(image_path),width=w,height=h),Spacer(1,5),Paragraph(inline(label),caption)]))
            skip_image=True
        elif kind=='h2':story.append(Paragraph(inline(value),chapter))
        elif kind=='h3':story.append(Paragraph(inline(value),sub))
        elif kind=='p':story.append(Paragraph(inline(value),body))
        elif kind=='list':story.append(Paragraph(inline(value),body))
        elif kind=='code':
            lines=value.splitlines()
            content='<br/>'.join(html.escape(x).replace(' ','&#160;') for x in lines)
            story.append(Paragraph(content,code))
        elif kind=='image':
            if skip_image:
                skip_image=False
                continue
            label,path=value;image_path=OUT/path
            im=Image.open(image_path);w=doc.width-12;h=w*im.height/im.width
            story.append(KeepTogether([PDFImage(str(image_path),width=w,height=h),Spacer(1,5),Paragraph(inline(label),caption)]))
        elif kind=='table':
            count=len(value[0]);
            weights=[math.sqrt(max(5,sum(len(row[j]) for row in value if len(row)>j)/len(value))) for j in range(count)]
            weights=[max(2.5,min(7,x)) for x in weights];widths=[doc.width*x/sum(weights) for x in weights]
            cells=[[Paragraph(inline(v),head if i==0 else cell) for v in row] for i,row in enumerate(value)]
            table=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
            table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor(NAVY)),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#d9d9d9')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f6f8fa')])]))
            story.extend([table,Spacer(1,10)])
    doc.multiBuild(story)


def notes(stats):
    (OUT/'README.md').write_text(f'''# GME HMI와 PLC 매뉴얼 파일 안내

2026년 10월 7일 기준 기술 자료다. 원본 프로젝트와 실제 설비를 변경하지 않고 화면, 설정 파일, 백업 검색 색인, 알람 DB를 확인해 작성했다.

- [상세 매뉴얼 PDF](GME_HMI_PLC_manual.pdf): 목차와 페이지 번호가 있는 열람용 문서
- [검색 가능한 HTML](manual.html): 브라우저에서 검색하고 장별로 이동
- [Markdown 원본](manual.md): 이후 수정과 이력 관리에 사용
- [PLC 통신 장애 확인 기록](PLC_communication_check_20261007.md)
- [블록 목록](references/blocks.csv): 속성 문서 {stats['blocks']}개
- [네트워크 목록](references/networks.csv): 검색 색인 문서 {stats['networks']}개
- [HMI PLC 태그 목록](references/hmi_plc_tags.csv): 설정 {stats['hmi_tags']}개
- [HMI 화면 목록](references/hmi_windows.csv): 화면 메타데이터 {stats['hmi_windows']}개
- [검증 대장](references/verification.csv): 추가 확인 {stats['verification']}개

그림 PNG와 수정 가능한 SVG는 assets 폴더에 있다. HTML과 Markdown을 옮길 때는 전체 폴더를 함께 복사한다. PDF는 단독으로 읽을 수 있다. CSV는 Excel에서 열 수 있도록 UTF-8 BOM으로 저장했다.

현재 물리 PLC와 2월·6월 보관 프로젝트의 전체 일치 여부는 아직 확인되지 않았다. 백업의 검색 토큰은 다운로드 가능한 소스가 아니며 접점 연결을 완전히 보존하지 않는다. 현장 표시값은 관찰 시점의 값이다. 개선안은 아직 구현하거나 적용하지 않은 설계 제안이다.

홈페이지는 GitHub와 Netlify를 연결해 운영하도록 선택했다. [홈페이지 시작 화면](index.html)은 이 폴더에서 바로 열 수 있다. Netlify Identity와 Blobs를 사용하는 서버 자료실 소스도 준비했다. [배포 상태 안내](배포_상태_안내.md)에서 게시 및 GitHub 업로드의 실제 상태를 확인한다.

PLC 아카이브, HMI 실행 파일, SQL DB 백업, VM 디스크와 라이선스는 이 문서 묶음에 포함하지 않았다. 이 문서 묶음은 설비 전체를 복원하는 백업 파일이 아니다.
''',encoding='utf-8')
    (OUT/'CHANGELOG.md').write_text('''# 문서 변경 이력

## 1.0 2026년 10월 7일

- HMI 화면과 PLC 실행 구조, 장치별 제어, 자동 순서, PV01 진단을 작성했다.
- PV01 네 가지 개선안과 명령당 두 번 실패 처리의 조건과 시험 범위를 정리했다.
- Historical Alarms의 SQL 저장 증거와 태그 이력 경로를 구분했다.
- Main Network 14와 15의 유지보수 제한 로직 및 실제 재발 기록을 정리했다.
- 원본 백업 위치, 복구 범위, 주소 호환 계층과 단계적 개선 절차를 작성했다.
- 10월 7일 유선 링크 단절과 PLC 통신 장애의 현재 증거를 추가했다.
- 시스템·실행·PV01·유지보수·개선 구성도와 탐색용 CSV를 작성했다.
- Markdown, HTML, PDF와 홈페이지를 파일로 제공한다.

## 1.1 2026년 10월 7일

- 홈페이지 운영 방식을 GitHub와 Netlify 연결로 변경했다.
- 서버 자료실을 Netlify Identity와 Blobs로 구성하고, 업로드를 파일당 최대 4MB로 제한했다.
- 실제 게시 및 이메일 발송 결과는 배포 상태 안내에 별도로 기록한다.
''',encoding='utf-8')
    (QA/'build_stats.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')


def main():
    md=(OUT/'manual.md').read_text('utf-8')
    diagrams();stats=references(md);make_pdf(md);stats['pdf_pages']=len(PdfReader(OUT/'GME_HMI_PLC_manual.pdf').pages);notes(stats)
    print(json.dumps(stats,ensure_ascii=False))
    print('PDF created:',OUT/'GME_HMI_PLC_manual.pdf')


if __name__=='__main__':main()
