from pathlib import Path
import zipfile, hashlib, json
base = Path(r'C:\Users\GME\Documents\Codex\2026-10-01\d')
out = base/'outputs/GME_manual_20261007'
site = base/'sites/gme-plc-manual'
exclude = {'node_modules','.sites-runtime','.wrangler','dist','.vinext','.next','.git','.agents','.codex','out','outputs','work'}
source_files = []
for directory, directories, files in __import__('os').walk(site):
    directories[:] = [name for name in directories if name not in exclude]
    for name in files:
        if name.startswith('.env') or name.endswith('.tsbuildinfo') or name=='next-env.d.ts': continue
        source_files.append(Path(directory)/name)
source_zip = out/'GME_홈페이지_소스.zip'
with zipfile.ZipFile(source_zip, 'w', zipfile.ZIP_DEFLATED, strict_timestamps=False) as archive:
    for file in sorted(source_files): archive.write(file,Path('gme-plc-manual')/file.relative_to(site))
manifest=[]
for file in sorted(out.rglob('*')):
    if file.is_file() and file.name != 'bundle_manifest.json':
        manifest.append({'path':file.relative_to(out).as_posix(),'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
(out/'bundle_manifest.json').write_text(json.dumps({'document_version':'1.0','date':'2026-10-07','files':manifest},ensure_ascii=False,indent=2),encoding='utf8')
bundle = base/'outputs/GME_매뉴얼_전체자료_20261007.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,strict_timestamps=False) as archive:
    for file in sorted(out.rglob('*')):
        if file.is_file(): archive.write(file,Path(out.name)/file.relative_to(out))
with zipfile.ZipFile(source_zip) as archive:
    names=archive.namelist()
    assert not any(part in exclude for name in names for part in Path(name).parts)
    assert archive.testzip() is None
with zipfile.ZipFile(bundle) as archive: assert archive.testzip() is None
print(json.dumps({'source_files':len(source_files),'source_zip_bytes':source_zip.stat().st_size,'bundle_files':len(manifest)+1,'bundle_zip_bytes':bundle.stat().st_size,'bundle_path':str(bundle)},ensure_ascii=False))
