"""Rebuild PDF from the existing Markdown and assets without reading the live HMI."""
from pathlib import Path
import ast, os, sys

root = Path(__file__).resolve().parent.parent
manual = root/'manual'
source = root/'scripts/original/build_gme_manual.py'
tree = ast.parse(source.read_text(encoding='utf-8'))
names = {'inline','parse_md','ManualDoc','make_pdf'}
colors = {'NAVY','BLUE','TEAL','AMBER','INK','GRAY'}
nodes = []
for node in tree.body:
    if isinstance(node,(ast.Import,ast.ImportFrom)):
        nodes.append(node)
    elif isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in names:
        nodes.append(node)
    elif isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in colors for t in node.targets):
        nodes.append(node)
module = ast.Module(body=nodes,type_ignores=[])
ast.fix_missing_locations(module)
scope = {'__name__':'portable_gme_pdf','OUT':manual,
         'FONT':os.environ.get('GME_FONT','C:/Windows/Fonts/malgun.ttf'),
         'BOLD':os.environ.get('GME_FONT_BOLD','C:/Windows/Fonts/malgunbd.ttf')}
exec(compile(module,str(source),'exec'),scope)
markdown = (manual/'manual.md').read_text(encoding='utf-8')
parts = list(scope['parse_md'](markdown))
if '--check' in sys.argv:
    print('Parser OK:',sum(k=='h2' for k,v in parts),'chapters')
    sys.exit(0)
for key in ['FONT','BOLD']:
    if not Path(scope[key]).is_file():
        raise SystemExit('Set GME_FONT and GME_FONT_BOLD to installed Korean TTF fonts.')
scope['make_pdf'](markdown)
print(manual/'GME_HMI_PLC_manual.pdf')
