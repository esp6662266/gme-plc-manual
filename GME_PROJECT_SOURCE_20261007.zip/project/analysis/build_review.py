from pathlib import Path
import json, csv, html
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parent
blocks = json.loads((root/'block_summary.json').read_text(encoding='utf-8'))
escape = html.escape
W,H=1500,1140
im=Image.new('RGB',(W,H),'#f3f6fa'); d=ImageDraw.Draw(im)
font_path='C:/Windows/Fonts/malgun.ttf'
fonts={n:ImageFont.truetype(font_path,n) for n in [16,18,20,22,26,34]}
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}"><rect width="100%" height="100%" fill="#f3f6fa"/><defs><marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="#64748b"/></marker></defs>']
def text(x,y,t,size=20,color='#172b4d'):
    d.text((x,y),t,font=fonts[size],fill=color)
    svg.append(f'<text x="{x}" y="{y+size}" font-family="Malgun Gothic, sans-serif" font-size="{size}" fill="{color}">{escape(t)}</text>')
def box(x,y,w,h,title,lines,color='#e9f0ff'):
    d.rounded_rectangle((x,y,x+w,y+h),radius=12,fill=color,outline='#ced8e6',width=2)
    svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="{color}" stroke="#ced8e6"/>')
    text(x+18,y+8,title,22)
    for i,line in enumerate(lines): text(x+18,y+42+i*25,line,18,'#42526e')
def arrow(x1,y1,x2,y2):
    d.line((x1,y1,x2,y2),fill='#64748b',width=3)
    if y2>y1: d.polygon([(x2,y2),(x2-5,y2-10),(x2+5,y2-10)],fill='#64748b')
    elif x2>x1: d.polygon([(x2,y2),(x2-10,y2-5),(x2-10,y2+5)],fill='#64748b')
    svg.append(f'<path d="M{x1},{y1} L{x2},{y2}" fill="none" stroke="#64748b" stroke-width="2" marker-end="url(#arrow)"/>')

text(45,24,'GME PLC 프로그램 구성도',34)
text(45,76,'백업 GME_20250506.zap18 · 내부 프로젝트 GME_20250605.ap18 · TIA V18',18)
text(45,105,'백업 검색 색인 기반 구성 — 실기 PLC 일치 여부·접점 조건·실행 상태는 미확인',18,'#67758b')
box(45,160,390,100,'InTouch HMI / WindowViewer',['운전 명령 · 설정값 · 상태 · 알람','OI.SIDIR → PLC 통신 설정'], '#dff3ef')
arrow(435,210,485,210)
box(485,160,480,100,'SIMATIC CPU 1515-2 PN',['6ES7 515-2AN03-0AB0','HMI 설정 대상 IP: 190.168.200.230'])
arrow(965,210,1015,210)
box(1015,160,440,100,'분산 I/O 구성 흔적',['153IM155_JB1 / 182IM155_JB2','PROFINET 장치명 확인 · IP 매핑 미확인'])
text(45,290,'Main: 검색 색인에서 확인한 네트워크 배치 순서',26)
text(940,290,'별도 주기 실행 OB',26)
steps=[
('① HMI·레시피', ['Recipes handler / HMI','HMI output / HMI inputs']),
('② 데이터 입출력', ['Word_inputs / Word_outputs','Analog input conversion']),
('③ 알람 판정', ['Allarms 1 / Allarms 2 / Allarms 3','모터 · 센서 · 공정 상태 검사']),
('④ 설비 제어', ['Motors 1 / Filter / R1 scraps gate 2','Burner control / Motor/alarm client / Time work motor']),
('⑤ 출력 제어', ['Valve control loop','Analog output conversion']),
('⑥ 알람 통합', ['Allarm manager','사이렌 · 확인/리셋 처리'])]
for i,(title,lines) in enumerate(steps):
    y=335+i*111
    box(45,y,830,94,title,lines)
    if i<5: arrow(460,y+94,460,y+111)
box(940,335,515,188,'100ms · CYC_INT5',['RO01 산소 → MV05 / PC01 압력 → MV02','TC03 온도 → MV01 / VT02 속도','Control_stechio: 공기·가스 비율 계산','MV03 PID는 off / not used 흔적'], '#fff0db')
box(940,550,515,161,'1초 · CYC_INT2',['TC01·TC02 온도 선택 → PID-Burner','Auto start motors: 예열·생산·정지 순서','버너 공기 출력 변화 지연 처리'], '#fff0db')
box(940,738,515,105,'200ms · CYC_INT4',['시험용 추세 네트워크','off 조건 흔적: 운전 중 활성 여부 미확인'], '#fff0db')
box(940,870,515,132,'기동·오류 처리 OB',['Startup only: 플래그/기본 상태 초기화','I/O_FLT1 / MOD_ERR / PROG_ERR','RACK_FLT / TOD_INT0'])
text(45,1022,'공유 데이터',22)
text(45,1060,'Inputs · Output · Flag · Data / Data2 · Motors · Allarm · HMI_DB · Workdata · Stechio · Data_PID',18)
text(45,1093,'화살표는 구조·배치 설명용입니다. PLC 접점 조건과 물리 배선·공정 물질 흐름을 나타내지 않습니다.',16,'#67758b')
svg.append('</svg>')
(root/'PLC_구성도.svg').write_text('\n'.join(svg),encoding='utf-8')
im.save(root/'PLC_구성도.png')

roles={
 'main':'순환 실행의 진입부. HMI, 입출력 데이터, 알람, 설비와 출력 제어를 배치합니다.',
 'hmi':'현장 피드백과 알람을 HMI용 모터·밸브 상태로 모읍니다.',
 'hmi inputs':'현장 입력을 Inputs 데이터와 연계하는 블록입니다.',
 'hmi output':'명령·출력 정보를 HMI 데이터와 연계합니다. 방향의 세부 의미는 네트워크에서 확인해야 합니다.',
 'recipes handler':'레시피 데이터 처리. SCL로 작성된 블록입니다.',
 'analog input conversion':'온도·압력·유량 등 아날로그 입력 변환.',
 'analog output conversion':'설정값과 내부 제어값을 아날로그 출력에 연결합니다.',
 'motors 1':'모터별 고장·허가·모드 조건을 받아 운전 명령을 생성합니다.',
 'auto start motors':'예열·생산·전체 정지 등 순차 운전과 운전/생산 카운터를 처리합니다.',
 'burner control':'버너 준비·기동·세정·화염·잠금과 자동/수동 출력을 처리합니다.',
 'valve control loop':'MV01~MV06의 열림/닫힘, 자동/수동, 리미트 및 일부 엔코더 보정을 처리합니다.',
 'control_stechio':'공기/가스 유량 비율과 이론 곡선, PID 보정으로 가스 출력을 계산합니다.',
 'allarms 1':'모터 알람 판정.', 'allarms 2':'공정·장치 알람 판정. 구체적 항목은 아래 네트워크 목록을 참조하세요.',
 'allarms 3':'추가 장치·공정 알람 판정.', 'allarm manager':'알람 통합·사이렌 및 확인/리셋 처리.',
 'filter':'필터 펄스/청소 운전 처리.', 'r1 scraps gate 2':'R1 게이트·유압 피스톤 운전 처리.',
 'time work motor':'모터 운전 시간 집계.',
 'cyc_int2 ogni 1s':'온도 센서 선택, 버너 PID, 자동 순차 운전: 1초 주기 이름/주석 확인.',
 'cyc_int4 ogni 200ms':'200ms 시험용 추세 네트워크. off 참조가 확인됩니다.',
 'cyc_int5 ogni 100ms':'산소·압력·온도 PID와 공기/가스 비율 계산: 100ms 주기 이름/호출 확인.',
 'startup only':'기동 시 On/Off 플래그와 DB 초기화·기본 모드 설정.'}
type_label={'101':'OB 추정','102':'FB 추정','103':'FC 추정','104':'DB 추정','401':'PID 인스턴스 DB','404':'HSC 인스턴스 DB'}
def bt(b): return type_label.get(b.get('filter'),'OB (주기 실행)')
with (root/'PLC_블록목록.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['블록명(색인 소문자)','분류','언어','네트워크 수','제목/역할','인스턴스 설명'])
    for b in blocks:w.writerow([b['name'],bt(b),b['properties'].get('Language',''),len(b['networks']),roles.get(b['name'],b['properties'].get('Title','')),b['properties'].get('Instance DB','')])

guide='''# GME PLC 학습 안내 — 1차 구성 분석

분석일: 2026-10-01

## 분석 범위와 신뢰 수준

- 분석 파일: `GME_20250506.zap18`. 내부 프로젝트 파일명은 `GME_20250605.ap18`입니다.
- 프로젝트 메타데이터 버전은 `18.0.1.0`입니다.
- 백업 안의 검색 색인 4개 세그먼트를 읽고 삭제 표시가 있는 문서는 제외했습니다. 블록 속성 문서 89개가 확인됩니다. 전체 프로젝트의 공식 블록 개수를 보증하는 수치는 아닙니다.
- 블록 이름, 주석, 네트워크의 검색 토큰과 배치 순서를 기준으로 분석했습니다. 검색 색인은 원본 소스 내보내기가 아니며 대소문자, 공백, 구문과 접점 연결 정보가 손실될 수 있습니다.
- TIA Portal 화면·컴파일·교차 참조·온라인 PLC와의 비교는 수행하지 못했습니다. VMware는 관리자 권한으로 실행 중이어서 UI 입력과 종료가 제한되었습니다. 실제 접점 조건, 블록 번호, 활성 경로, 다운로드된 프로그램 일치 여부는 후속 확인 대상입니다.
- 현재 PLC 연결·다운로드·강제 출력·프로그램 수정은 수행하지 않았습니다.

## 전체 구성

![PLC 구성도](PLC_구성도.png)

HMI는 AVEVA InTouch WindowViewer이며, 기존 OI.SIDIR 설정의 통신 대상은 `190.168.200.230`, Rack 0 / Slot 1입니다. PLC 프로젝트에는 CPU 1515-2 PN 및 `6ES7 515-2AN03-0AB0` 식별 문자열이 있습니다. 분산 I/O 장치명 `153IM155_JB1`, `182IM155_JB2`의 PROFINET 인터페이스가 색인에서 확인됩니다. 프로젝트에 있는 .231/.232 IP와 각 장치의 대응 관계는 미확인입니다.

## Main을 읽는 순서

1. `Simulation` 참조: 시뮬레이션 관련 분기입니다. 참조가 있다고 실제 활성 상태인 것은 아닙니다.
2. `Recipes handler`, `HMI`, `HMI output`, `HMI inputs`: 레시피와 화면 상태/명령 연계입니다.
3. `Word_inputs`, `Word_outputs`: 입출력 워드 데이터의 이동 네트워크입니다.
4. `Analog input conversion`, `Allarms 1/2/3`: 센서 변환과 알람 조건 검사입니다.
5. `Motors 1`, `Filter`, `R1 scraps gate 2`, `Burner control`, `Motor/alarm client`, `Time work motor`: 장치별 운전 조건·명령·시간 관리입니다.
6. `Valve control loop`, `Analog output conversion`: 밸브 동작과 아날로그 출력입니다.
7. `Allarm manager`: 알람 통합과 사이렌입니다.
8. CPU 시계 및 정비 기간 관련 네트워크가 뒤에 있습니다.

이는 Main의 색인상 네트워크 배치 순서입니다. 조건부 실행 및 PLC 전체 실행 순서와 동등하지 않습니다. 주기 OB는 별도로 실행됩니다.

## 시간 주기별 처리

| 블록 | 색인에서 확인되는 기능 | 주의할 점 |
|---|---|---|
| CYC_INT5 ogni 100ms | RO01→MV05, PC01→MV02, TC03→MV01·VT02, Control_stechio 호출 | 주기 이름과 PID Cycle=T#100ms를 확인. 실제 OB 속성 미확인 |
| CYC_INT2 ogni 1s | TC01/TC02 온도 선택, PID-Burner, Auto start motors, 공기 출력 변화 제한 | PID Cycle=T#1s와 호출 확인 |
| CYC_INT4 ogni 200ms | 추세 시험용 값 증가/이동 | off 참조가 있으며 실제 활성 여부 미확인 |
| Startup only | 특수 플래그, 시작·알람 데이터 초기화, 기본 모드 | 기동 이벤트 종류와 번호는 TIA 속성에서 확인 필요 |
| I/O_FLT1, MOD_ERR, PROG_ERR, RACK_FLT | I/O·접근·프로그램·스테이션 오류 이벤트 블록 | 블록 존재만으로 오류 처리의 충분성을 판단할 수 없음 |

`Auto start motors`의 제목에는 “every 1ms”가 있지만, 실제 색인 호출은 1초 주기 블록 안에 있습니다. 학습 시 주석보다 호출 위치와 OB 설정을 우선 확인해야 합니다.

## 데이터 블록을 이해하는 방법

| 이름 | 학습 시 읽을 내용 |
|---|---|
| Inputs | 운전 피드백, 리미트 스위치, 장치 상태 |
| Output / Word_outputs | 출력 데이터·워드 |
| Flag | 수동 명령, 자동 모드, 시작·리셋 플래그 |
| Motors | 모터·밸브의 HMI용 피드백과 알람 상태 |
| Data / Data2 | 설정값, 온도·압력·속도·운전 선택 값 |
| Allarm | 고장·온도·산소·비상정지·정비 관련 알람 |
| HMI_DB | 화면 명령, 보정 절차, 생산 카운터 등의 화면 데이터 |
| Workdata | 버너 상태 단계와 계산 중간값 |
| Stechio / Data_PID | 공기·가스 비율과 PID 조정 데이터 |
| PID-* / MV*_encoder | PID·고속 카운터 인스턴스 데이터 |

DB 번호와 이름의 대응은 아직 확정하지 않았습니다. HMI가 참조하는 DB 주소 목록과 블록 이름을 임의로 연결하지 않았습니다.

## 처음 공부할 장치: BC01

`HMI`의 BC01 네트워크에서 운전 피드백과 고장 정보를 `Motors.BC01` 상태에 모읍니다. `Motors 1`의 BC01 네트워크에는 `Flag.m_BC_01`, 고장·인버터·리미트 관련 알람, 게이트 관련 플래그와 `Start BC01` 참조가 있습니다. `Auto start motors`에도 BC01 기동 단계가 들어 있습니다.

따라서 다음 순서로 읽으면 장치 하나의 흐름을 이해하기 쉽습니다.

**화면 명령 → Flag → 자동 순차 기동 → Motors 1의 허가/고장 검사 → Start BC01 → 출력 주소 → 현장 RUN 피드백 → HMI 표시**

위 흐름은 학습 경로입니다. 실제 출력 주소와 AND/OR·접점 극성·타이머 조건은 TIA 네트워크에서 확인해야 합니다.

## 버너·밸브 제어를 공부할 때

- 1초 블록은 TC01/TC02의 선택 및 오류 상태에 따라 버너 PID 기준 온도를 처리합니다.
- 100ms 블록은 산소·압력·온도에 따른 밸브·팬 PID와 `Control_stechio`를 처리합니다.
- `Control_stechio`는 공기 유량/가스 유량 비율, 가스 곡선과 PID 보정값을 사용합니다.
- `Burner control`에는 준비, 기동, 세정, 고화염, 자동 출력, 잠금 관련 네트워크가 있습니다.
- `Valve control loop`는 PID 방향 명령과 수동 명령, 열림/닫힘 리미트 및 일부 엔코더 보정을 연결합니다.
- MV03 PID 네트워크는 `off`와 “not used” 주석이 있습니다. MV03의 실제 제어는 다른 네트워크도 함께 읽어야 합니다.

## 다음 검토에서 확인할 구체적 항목

1. Main의 `Maintenance period limits`에 날짜 `D#2026-01-01` 비교와 `Allarm.maintenance_period_limit` 설정 흔적이 있습니다. 오늘 날짜는 그 이후지만 조건 분기·현재 값·온라인 상태가 미확인이므로 현재 알람 발생을 단정하지 않습니다. 학습·점검 항목으로 남깁니다.
2. `Auto start motors`의 1ms 주석과 1초 호출 위치가 다릅니다.
3. 이름에 “deleted”가 남아 있는 빈 네트워크 및 off 조건의 시험 네트워크가 있습니다.
4. HMI와 PLC 백업이 동일한 버전인지, 실제 PLC에 어느 버전이 적재되어 있는지 확인이 필요합니다.

## 저장한 자료

- `PLC_구성도.png`, `PLC_구성도.svg`: 학습용 구조도
- `PLC_프로그램_분석.html`: 검색 가능한 블록·네트워크 목록
- `PLC_블록목록.csv`: 엑셀에서 열 수 있는 블록 속성 목록
- `block_summary.json`, `live_index.json`: 분석 근거. 코드 문자열은 검색 토큰 재구성이며 실행용 소스가 아닙니다.

## VMware 업데이트 설정

사용자 요청에 따라 `%APPDATA%/VMware/preferences.ini`에 `pref.autoSoftwareUpdatePermission = "DENY"`를 저장했습니다. 변경 전 파일은 `vmware_preferences_before.ini`에 보관했습니다. 현재 관리자 권한의 VMware 종료가 액세스 거부되어 재실행 검증은 못 했습니다. 다음 재실행 후 알림과 설정을 확인해야 합니다. 현재 버전은 17.5.1입니다.
'''
(root/'PLC_학습_안내.md').write_text(guide,encoding='utf-8')
cards=[]
for b in blocks:
    detail=[]
    for i,n in enumerate(b['networks'],1):
        code=n.get('LADFBD Code') or n.get('STL Code') or n.get('SCL Code') or ''
        detail.append(f'<details><summary>{i:02d} · {escape(n.get("Network title") or "제목 없음")}</summary><p class="muted">색인 {escape(n["segment"])} / 문서 {n["doc"]} · 검색 토큰 재구성, 실행용 소스 아님</p><pre>{escape(code)}</pre></details>')
    props=' · '.join(x for x in [bt(b),b['properties'].get('Language','').upper(),b['properties'].get('Instance DB','')] if x)
    cards.append(f'<article><h3>{escape(b["name"])}</h3><p class="meta">{escape(props)} · 네트워크 {len(b["networks"])}개</p><p>{escape(roles.get(b["name"],b["properties"].get("Title","데이터/보조 블록: 네트워크 또는 인스턴스 설명을 참조하세요.")))}</p>{"".join(detail)}</article>')
page='''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>GME PLC 프로그램 학습 자료</title><style>
body{margin:0;background:#f3f6fa;color:#172b4d;font-family:'Malgun Gothic',sans-serif;line-height:1.65}main{max-width:1120px;margin:auto;padding:36px 24px}h1{font-size:32px}h2{margin-top:38px}img{width:100%;border-radius:16px}section,article{background:white;border:1px solid #dce3ee;border-radius:14px;padding:22px;margin:16px 0}.meta,.muted{color:#64748b;font-size:14px}input{width:100%;box-sizing:border-box;padding:14px;border-radius:10px;border:1px solid #b9c6d8;font:inherit}summary{cursor:pointer;padding:8px;font-weight:600}details{border-top:1px solid #edf0f5}pre{font-size:13px;white-space:pre-wrap;word-break:break-word;background:#f5f7fb;padding:14px;border-radius:8px}a{color:#235cba}.notice{background:#fff6e6} @media print{input{display:none}article{break-inside:avoid}}
</style><main><p class="meta">GME · 학습 자료 · 2026-10-01</p><h1>PLC 프로그램을 읽는 지도</h1><p>화면 → 명령 데이터 → 설비 제어 → 출력 → 피드백 순서로 장치 하나씩 추적하세요.</p><section class="notice"><b>백업 색인에 근거한 1차 분석</b><p>GME_20250506.zap18 / 내부 GME_20250605.ap18 / TIA V18. 삭제 색인은 제외했습니다. TIA 화면·컴파일·온라인 PLC 일치 여부는 미확인입니다. 아래 코드는 검색 토큰 재구성이며 접점 연결을 복원한 실행 소스가 아닙니다.</p></section><img src="PLC_구성도.png" alt="PLC 구조 및 실행 주기 구성도"><section><h2>학습 순서</h2><ol><li>Main의 호출 배치를 읽습니다.</li><li>BC01처럼 장치 하나를 골라 HMI → Flag → Motors 1 → 출력 → 피드백을 추적합니다.</li><li>Allarms 1/2/3과 Allarm manager를 읽어 정지/표시 조건을 구분합니다.</li><li>Auto start motors의 예열·생산·정지 순서를 읽습니다.</li><li>버너의 1초 PID와 100ms 밸브/가스 비율 제어를 읽습니다.</li></ol><p><a href="PLC_학습_안내.md">상세 학습 안내</a> · <a href="PLC_블록목록.csv">블록 목록 CSV</a> · <a href="PLC_구성도.svg">SVG 구성도</a></p></section><section class="notice"><b>다음 TIA 검토 항목</b><p>Main에 2026-01-01 날짜 비교와 정비 기간 알람 설정 흔적이 있습니다. 현재 알람 발생은 미확인입니다. Auto start motors의 1ms 주석과 1초 호출 위치도 다릅니다. 시험/off 네트워크와 실제 활성 경로는 TIA에서 확인해야 합니다.</p></section><h2>블록·네트워크 찾아보기</h2><p class="muted">89개 블록 속성 문서. 공식 전체 블록 수를 보증하지 않습니다. 이름은 검색 색인의 소문자 표기입니다.</p><input id="search" placeholder="예: BC01, burner, maintenance, mv02" aria-label="블록과 네트워크 검색"><div id="cards">'''+''.join(cards)+'''</div><p id="count" class="muted"></p><script>const input=document.querySelector('#search');const cards=[...document.querySelectorAll('article')];function filter(){const q=input.value.toLowerCase();let n=0;for(const card of cards){const show=card.textContent.toLowerCase().includes(q);card.hidden=!show;if(show)n++;}document.querySelector('#count').textContent=n+'개 블록 표시';}input.addEventListener('input',filter);filter();</script></main></html>'''
(root/'PLC_프로그램_분석.html').write_text(page,encoding='utf-8')
print(json.dumps({'blocks':len(blocks),'png':str(root/'PLC_구성도.png'),'html':str(root/'PLC_프로그램_분석.html')},ensure_ascii=True))
