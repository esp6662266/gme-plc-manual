# GME PLC 학습 안내 — 1차 구성 분석

분석일: 2026-10-01

## 분석 범위와 신뢰 수준

- 분석 파일: `GME_20250506.zap18`. 내부 프로젝트 파일명은 `GME_20250605.ap18`입니다.
- 프로젝트 메타데이터 버전은 `18.0.1.0`입니다.
- 백업 안의 검색 색인 4개 세그먼트를 읽고 삭제 표시가 있는 문서는 제외했습니다. 블록 속성 문서 89개가 확인됩니다. 전체 프로젝트의 공식 블록 개수를 보증하는 수치는 아닙니다.
- 블록 이름, 주석, 네트워크의 검색 토큰과 배치 순서를 기준으로 분석했습니다. 검색 색인은 원본 소스 내보내기가 아니며 대소문자, 공백, 구문과 접점 연결 정보가 손실될 수 있습니다.
- TIA Portal 화면·컴파일·교차 참조·온라인 PLC와의 비교는 수행하지 못했습니다. VMware는 관리자 권한으로 실행 중이어서 UI 입력과 종료가 제한되었습니다. 실제 접점 조건, 블록 번호, 활성 경로, 다운로드된 프로그램 일치 여부는 후속 확인 대상입니다.
- 현재 PLC 연결·다운로드·강제 출력·프로그램 수정은 수행하지 않았습니다.

## 전체 구성

![PLC 구성도](PLC_구성도.png)

HMI는 AVEVA InTouch WindowViewer이며, 기존 OI.SIDIR 설정의 통신 대상은 `190.168.200.230`, Rack 0 / Slot 1입니다. PLC 프로젝트에는 CPU 1515-2 PN 및 `6ES7 515-2AN03-0AB0` 식별 문자열이 있습니다. 분산 I/O 장치명 `153IM155_JB1`, `182IM155_JB2`의 PROFINET 인터페이스가 색인에서 확인됩니다. 프로젝트에 있는 .231/.232 IP와 각 장치의 대응 관계는 미확인입니다.

## Main을 읽는 순서

1. `Simulation` 참조: 시뮬레이션 관련 분기입니다. 참조가 있다고 실제 활성 상태인 것은 아닙니다.
2. `Recipes handler`, `HMI`, `HMI output`, `HMI inputs`: 레시피와 화면 상태/명령 연계입니다.
3. `Word_inputs`, `Word_outputs`: 입출력 워드 데이터의 이동 네트워크입니다.
4. `Analog input conversion`, `Allarms 1/2/3`: 센서 변환과 알람 조건 검사입니다.
5. `Motors 1`, `Filter`, `R1 scraps gate 2`, `Burner control`, `Motor/alarm client`, `Time work motor`: 장치별 운전 조건·명령·시간 관리입니다.
6. `Valve control loop`, `Analog output conversion`: 밸브 동작과 아날로그 출력입니다.
7. `Allarm manager`: 알람 통합과 사이렌입니다.
8. CPU 시계 및 정비 기간 관련 네트워크가 뒤에 있습니다.

이는 Main의 색인상 네트워크 배치 순서입니다. 조건부 실행 및 PLC 전체 실행 순서와 동등하지 않습니다. 주기 OB는 별도로 실행됩니다.

## 시간 주기별 처리

| 블록 | 색인에서 확인되는 기능 | 주의할 점 |
|---|---|---|
| CYC_INT5 ogni 100ms | RO01→MV05, PC01→MV02, TC03→MV01·VT02, Control_stechio 호출 | 주기 이름과 PID Cycle=T#100ms를 확인. 실제 OB 속성 미확인 |
| CYC_INT2 ogni 1s | TC01/TC02 온도 선택, PID-Burner, Auto start motors, 공기 출력 변화 제한 | PID Cycle=T#1s와 호출 확인 |
| CYC_INT4 ogni 200ms | 추세 시험용 값 증가/이동 | off 참조가 있으며 실제 활성 여부 미확인 |
| Startup only | 특수 플래그, 시작·알람 데이터 초기화, 기본 모드 | 기동 이벤트 종류와 번호는 TIA 속성에서 확인 필요 |
| I/O_FLT1, MOD_ERR, PROG_ERR, RACK_FLT | I/O·접근·프로그램·스테이션 오류 이벤트 블록 | 블록 존재만으로 오류 처리의 충분성을 판단할 수 없음 |

`Auto start motors`의 제목에는 “every 1ms”가 있지만, 실제 색인 호출은 1초 주기 블록 안에 있습니다. 학습 시 주석보다 호출 위치와 OB 설정을 우선 확인해야 합니다.

## 데이터 블록을 이해하는 방법

| 이름 | 학습 시 읽을 내용 |
|---|---|
| Inputs | 운전 피드백, 리미트 스위치, 장치 상태 |
| Output / Word_outputs | 출력 데이터·워드 |
| Flag | 수동 명령, 자동 모드, 시작·리셋 플래그 |
| Motors | 모터·밸브의 HMI용 피드백과 알람 상태 |
| Data / Data2 | 설정값, 온도·압력·속도·운전 선택 값 |
| Allarm | 고장·온도·산소·비상정지·정비 관련 알람 |
| HMI_DB | 화면 명령, 보정 절차, 생산 카운터 등의 화면 데이터 |
| Workdata | 버너 상태 단계와 계산 중간값 |
| Stechio / Data_PID | 공기·가스 비율과 PID 조정 데이터 |
| PID-* / MV*_encoder | PID·고속 카운터 인스턴스 데이터 |

DB 번호와 이름의 대응은 아직 확정하지 않았습니다. HMI가 참조하는 DB 주소 목록과 블록 이름을 임의로 연결하지 않았습니다.

## 처음 공부할 장치: BC01

`HMI`의 BC01 네트워크에서 운전 피드백과 고장 정보를 `Motors.BC01` 상태에 모읍니다. `Motors 1`의 BC01 네트워크에는 `Flag.m_BC_01`, 고장·인버터·리미트 관련 알람, 게이트 관련 플래그와 `Start BC01` 참조가 있습니다. `Auto start motors`에도 BC01 기동 단계가 들어 있습니다.

따라서 다음 순서로 읽으면 장치 하나의 흐름을 이해하기 쉽습니다.

**화면 명령 → Flag → 자동 순차 기동 → Motors 1의 허가/고장 검사 → Start BC01 → 출력 주소 → 현장 RUN 피드백 → HMI 표시**

위 흐름은 학습 경로입니다. 실제 출력 주소와 AND/OR·접점 극성·타이머 조건은 TIA 네트워크에서 확인해야 합니다.

## 버너·밸브 제어를 공부할 때

- 1초 블록은 TC01/TC02의 선택 및 오류 상태에 따라 버너 PID 기준 온도를 처리합니다.
- 100ms 블록은 산소·압력·온도에 따른 밸브·팬 PID와 `Control_stechio`를 처리합니다.
- `Control_stechio`는 공기 유량/가스 유량 비율, 가스 곡선과 PID 보정값을 사용합니다.
- `Burner control`에는 준비, 기동, 세정, 고화염, 자동 출력, 잠금 관련 네트워크가 있습니다.
- `Valve control loop`는 PID 방향 명령과 수동 명령, 열림/닫힘 리미트 및 일부 엔코더 보정을 연결합니다.
- MV03 PID 네트워크는 `off`와 “not used” 주석이 있습니다. MV03의 실제 제어는 다른 네트워크도 함께 읽어야 합니다.

## 다음 검토에서 확인할 구체적 항목

1. Main의 `Maintenance period limits`에 날짜 `D#2026-01-01` 비교와 `Allarm.maintenance_period_limit` 설정 흔적이 있습니다. 오늘 날짜는 그 이후지만 조건 분기·현재 값·온라인 상태가 미확인이므로 현재 알람 발생을 단정하지 않습니다. 학습·점검 항목으로 남깁니다.
2. `Auto start motors`의 1ms 주석과 1초 호출 위치가 다릅니다.
3. 이름에 “deleted”가 남아 있는 빈 네트워크 및 off 조건의 시험 네트워크가 있습니다.
4. HMI와 PLC 백업이 동일한 버전인지, 실제 PLC에 어느 버전이 적재되어 있는지 확인이 필요합니다.

## 저장한 자료

- `PLC_구성도.png`, `PLC_구성도.svg`: 학습용 구조도
- `PLC_프로그램_분석.html`: 검색 가능한 블록·네트워크 목록
- `PLC_블록목록.csv`: 엑셀에서 열 수 있는 블록 속성 목록
- `block_summary.json`, `live_index.json`: 분석 근거. 코드 문자열은 검색 토큰 재구성이며 실행용 소스가 아닙니다.

## VMware 업데이트 설정

사용자 요청에 따라 `%APPDATA%/VMware/preferences.ini`에 `pref.autoSoftwareUpdatePermission = "DENY"`를 저장했습니다. 변경 전 파일은 `vmware_preferences_before.ini`에 보관했습니다. 현재 관리자 권한의 VMware 종료가 액세스 거부되어 재실행 검증은 못 했습니다. 다음 재실행 후 알림과 설정을 확인해야 합니다. 현재 버전은 17.5.1입니다.
