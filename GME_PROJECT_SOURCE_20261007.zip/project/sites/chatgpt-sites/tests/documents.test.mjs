import { build } from "esbuild";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, mkdirSync } from "node:fs";
import { pathToFileURL } from "node:url";
import path from "node:path";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";

// Test the actual route code with SQLite and an in-memory object store.
// This does not verify the unavailable Windows workerd runtime or hosted bindings.
const workdir = path.resolve(".sites-runtime/tests");
mkdirSync(workdir, { recursive: true });
const fixture = {
  user: null,
  env: {},
};
globalThis.__documentTest = fixture;
const database = new DatabaseSync(":memory:");
database.exec(readFileSync("drizzle/0000_narrow_doctor_strange.sql", "utf8").replaceAll("--> statement-breakpoint", ""));
const objects = new Map();
const db = { prepare(sql) {
  const statement = database.prepare(sql);
  return { bind(...values) { return {
    async all() { return { results: statement.all(...values) }; },
    async first() { return statement.get(...values) || null; },
    async run() { statement.run(...values); return { success: true }; },
  }; } };
} };
const bucket = {
  async put(key, bytes) { objects.set(key, new Uint8Array(bytes)); },
  async delete(key) { objects.delete(key); },
  async get(key) { const bytes = objects.get(key); return bytes ? { size: bytes.length, body: new Blob([bytes]).stream() } : null; },
};
const mockPlugin = { name: "test-bindings", setup(builder) {
  builder.onResolve({ filter: /^(cloudflare:workers)$|chatgpt-auth$/ }, args => ({ path: args.path, namespace: "test" }));
  builder.onLoad({ filter: /.*/, namespace: "test" }, args => ({
    contents: args.path === "cloudflare:workers" ? "export const env = globalThis.__documentTest.env;" : "export async function getChatGPTUser() { return globalThis.__documentTest.user; }",
  }));
} };
for (const [entry, output] of [["app/api/documents/route.ts", "documents"], ["app/api/documents/[id]/route.ts", "download"]]) {
  await build({ entryPoints: [entry], outfile: path.join(workdir, output + ".mjs"), bundle: true, platform: "node", format: "esm", plugins: [mockPlugin] });
}
const routes = await import(pathToFileURL(path.join(workdir, "documents.mjs")).href);
const download = await import(pathToFileURL(path.join(workdir, "download.mjs")).href);
const userA = { userId: "account-a", email: "a@example.test" };
const userB = { userId: "account-b", email: "b@example.test" };
const payload = async (response) => await response.json();
function upload(content = "first revision", name = "test.md", previousId = "", extraHeaders = {}) {
  const form = new FormData();
  form.set("title", "PV01 test"); form.set("category", "report"); form.set("note", "test record"); form.set("previousId", previousId);
  form.set("file", new File([content], name));
  return new Request("http://127.0.0.1/api/documents", { method: "POST", body: form, headers: { origin: "http://127.0.0.1", ...extraHeaders } });
}
assert.equal((await routes.GET()).status, 401);
assert.equal((await routes.POST(upload())).status, 401);
fixture.user = userA;
assert.equal((await routes.GET()).status, 503);
fixture.env.DB = db; fixture.env.BUCKET = bucket;
assert.deepEqual((await payload(await routes.GET())).documents, []);
assert.equal((await routes.POST(upload("x", "test.md", "", { origin: "https://other.example" }))).status, 403);
assert.equal((await routes.POST(upload("x", "test.html"))).status, 400);
assert.equal((await routes.POST(upload("", "test.md"))).status, 400);
assert.equal((await routes.POST(upload("x", "test.md", "", { "content-length": String(27 * 1024 * 1024) }))).status, 413);
const firstResponse = await routes.POST(upload());
assert.equal(firstResponse.status, 201);
const first = await payload(firstResponse);
const secondResponse = await routes.POST(upload("second revision", "revision.md", first.id));
assert.equal(secondResponse.status, 201);
const second = await payload(secondResponse);
assert.equal(second.version, 2);
const list = (await payload(await routes.GET())).documents;
assert.equal(list.length, 2);
assert.equal(list[0].familyId, list[1].familyId);
assert.equal(list.find(doc => doc.id === first.id).sha256, createHash("sha256").update("first revision").digest("hex"));
const firstDownload = await download.GET(new Request("http://127.0.0.1"), { params: Promise.resolve({ id: first.id }) });
assert.equal(await firstDownload.text(), "first revision");
assert.match(firstDownload.headers.get("content-disposition"), /^attachment;/);
assert.equal(firstDownload.headers.get("x-content-type-options"), "nosniff");
fixture.user = userB;
assert.deepEqual((await payload(await routes.GET())).documents, []);
assert.equal((await download.GET(new Request("http://127.0.0.1"), { params: Promise.resolve({ id: first.id }) })).status, 404);
assert.equal((await routes.POST(upload("third revision", "test.md", first.id))).status, 404);
fixture.user = userA;
const objectCount = objects.size;
fixture.env.DB = { prepare() { throw new Error("simulated database failure"); } };
assert.equal((await routes.POST(upload())).status, 500);
assert.equal(objects.size, objectCount, "R2 object must be removed if DB insert fails");
fixture.user = null;
assert.equal((await download.GET(new Request("http://127.0.0.1"), { params: Promise.resolve({ id: first.id }) })).status, 401);
database.close(); delete globalThis.__documentTest;
console.log("PASS: login, storage availability, origin check, file validation, revision preservation, SHA-256, download, account isolation, failed-save cleanup");
