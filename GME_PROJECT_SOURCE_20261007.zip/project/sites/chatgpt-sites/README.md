# GME HMI · PLC 기술 매뉴얼 홈페이지

기본 문서는 `public/manual/`에 있고 `/manual/index.html`에서 읽는다. `/library`는 ChatGPT 로그인 계정별 자료 보관함이다. 문서 제목·분류·개정 이력·SHA-256은 D1에 저장하고 첨부파일은 R2에 저장한다. 최대 파일 크기는 25MB이며 새 개정본을 올려도 기존 버전을 보존한다. PLC/HMI와 실시간 통신하거나 설정을 변경하는 기능은 없다.

## 게시 상태

2026-10-07 신규 Sites 등록은 `Site Hosting usage limit` 오류로 실패했다. 따라서 `.openai/hosting.json`에는 아직 `project_id`가 없다. 인터넷 운영 주소와 운영 DB는 생성되지 않았다. 기존 SEJIN 사이트는 변경하지 않았다. 사용 한도가 해제된 뒤 Sites의 신규 등록·소스 동기화·빌드·저장·배포 절차를 진행한다. 새 Site는 기본 비공개로 게시한다.

## 로컬 실행

Sites portable 프로필 및 Vinext starter를 사용한다. `npm run dev`로 로컬 미리보기를 연다. `/signin-with-chatgpt?return_to=/library`의 개발용 로그인은 로컬에서만 제공된다. 운영 인증은 ChatGPT Sites가 처리한다.

스키마는 `db/schema.ts`, 이행 SQL은 `drizzle/`에 있다. D1=`DB`, R2=`BUCKET` 바인딩을 선언했다. 미리보기의 D1/R2 데이터는 운영 데이터와 별개다. 기본 문서는 코드 저장소에 포함되므로 서버 자료 보관함에 중복 등록하지 않아도 열람·다운로드할 수 있다.

기본 문서 갱신은 `node scripts/sync-manual.mjs <매뉴얼 폴더 절대 경로>`로 수행한다. 기본 문서의 PDF, Markdown, 참조 CSV와 그림을 함께 갱신한다.

## 데이터 보관

자료 보관함의 등록·조회·다운로드는 서버에서 로그인 계정 ID를 확인한다. 개정 자료는 기존 계정의 자료에만 연결할 수 있다. 다운로드는 첨부파일로 반환한다. 소스 Git 저장소는 실행 코드와 기본 문서를 관리하며, 서버에 등록한 파일 자체를 보관하는 역할과 다르다. 서버 자료는 보관함에서 따로 내려받아 백업한다.

`.sites-runtime/`, `.wrangler/`, `node_modules/`와 로컬 인증 상태는 배포 소스에 포함하지 않는다. 운영 DB·R2 파일은 소스 ZIP에 포함되지 않는다.
