import { sqliteTable, text, integer, index, uniqueIndex } from "drizzle-orm/sqlite-core";
export const documents = sqliteTable("documents", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  familyId: text("family_id").notNull(),
  version: integer("version").notNull().default(1),
  title: text("title").notNull(),
  category: text("category").notNull(),
  note: text("note").notNull().default(""),
  filename: text("filename").notNull(),
  contentType: text("content_type").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  sha256: text("sha256").notNull(),
  objectKey: text("object_key").notNull(),
  createdAt: text("created_at").notNull(),
}, (table) => [
  index("documents_owner_created").on(table.ownerId, table.createdAt),
  uniqueIndex("documents_owner_family_version").on(table.ownerId, table.familyId, table.version),
]);
