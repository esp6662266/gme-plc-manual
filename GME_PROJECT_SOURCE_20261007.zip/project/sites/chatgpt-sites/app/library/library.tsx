"use client";
import { useEffect, useMemo, useState } from "react";
type DocumentRecord = { id: string; familyId: string; version: number; title: string; category: string; note: string; filename: string; sizeBytes: number; sha256: string; createdAt: string };
const categories: Record<string, string> = { manual: "매뉴얼", reference: "참조 자료", report: "점검 기록", backup: "백업 자료", other: "기타" };
const size = (bytes: number) => bytes >= 1048576 ? `${(bytes / 1048576).toFixed(2)} MB` : `${(bytes / 1024).toFixed(1)} KB`;
export default function Library() {
  const [records, setRecords] = useState<DocumentRecord[]>([]);
  const [loading, setLoading] = useState(true), [saving, setSaving] = useState(false);
  const [status, setStatus] = useState(""), [error, setError] = useState("");
  const [query, setQuery] = useState(""), [category, setCategory] = useState("all"), [history, setHistory] = useState(false);
  async function refresh() {
    setLoading(true); setError("");
    try {
      const response = await fetch("/api/documents", { cache: "no-store" });
      const data = await response.json() as { documents: DocumentRecord[]; error?: string };
      if (!response.ok) throw new Error(data.error || "목록을 읽지 못했습니다.");
      setRecords(data.documents);
    } catch (e) { setError(e instanceof Error ? e.message : "목록을 읽지 못했습니다."); }
    finally { setLoading(false); }
  }
  useEffect(() => { void refresh(); }, []);
  const latest = useMemo(() => {
    const families = new Map<string, DocumentRecord>();
    for (const record of records) if (!families.has(record.familyId) || families.get(record.familyId)!.version < record.version) families.set(record.familyId, record);
    return [...families.values()];
  }, [records]);
  const visible = (history ? records : latest).filter(record => (category === "all" || record.category === category) && `${record.title} ${record.filename} ${record.note}`.toLocaleLowerCase().includes(query.toLocaleLowerCase()));
  async function upload(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = event.currentTarget, data = new FormData(form);
    if ((data.get("file") as File).size > 25 * 1024 * 1024) { setError("파일은 25MB 이하여야 합니다."); return; }
    setSaving(true); setError(""); setStatus("");
    try {
      const response = await fetch("/api/documents", { method: "POST", body: data });
      const result = await response.json() as { version: number; error?: string };
      if (!response.ok) throw new Error(result.error || "저장하지 못했습니다.");
      form.reset(); setStatus(`서버에 ${result.version}번째 버전을 저장했습니다.`); await refresh();
    } catch (e) { setError(e instanceof Error ? e.message : "저장하지 못했습니다."); }
    finally { setSaving(false); }
  }
  return <div className="library-grid">
    <section className="upload-panel"><h2>자료 등록</h2><p>새 자료를 추가하거나 기존 자료의 개정본을 보관합니다.</p>
      <form onSubmit={upload}>
        <label>제목<input name="title" required maxLength={120} placeholder="예: PV01 게이트 점검 기록" /></label>
        <label>분류<select name="category">{Object.entries(categories).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select></label>
        <label>등록 방식<select name="previousId"><option value="">새 자료로 등록</option>{latest.map(doc => <option key={doc.id} value={doc.id}>{doc.title} · V{doc.version}의 개정본</option>)}</select></label>
        <label>변경 내용<textarea name="note" maxLength={2000} rows={4} placeholder="확인한 현상, 변경 이유나 자료의 출처" /></label>
        <label>파일<input name="file" type="file" required accept=".pdf,.md,.txt,.csv,.json,.png,.jpg,.jpeg,.webp,.zip,.zap18,.ap18" /></label>
        <p className="file-help">PDF, Markdown, CSV, 그림 및 백업 파일 · 파일당 최대 25MB</p>
        <button className="library-button primary" disabled={saving || loading}>{saving ? "저장 중…" : "서버에 저장"}</button>
      </form>
    </section>
    <section className="document-panel"><div className="document-heading"><h2>저장된 자료 <span>{latest.length}</span></h2><button className="library-button" onClick={() => void refresh()} disabled={loading}>목록 새로고침</button></div>
      <div className="library-filters"><label className="search-label">자료 검색<input type="search" placeholder="제목, 파일명, 변경 내용" value={query} onChange={e => setQuery(e.target.value)} /></label><label>분류<select value={category} onChange={e => setCategory(e.target.value)}><option value="all">전체</option>{Object.entries(categories).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select></label></div>
      <label className="history-toggle"><input type="checkbox" checked={history} onChange={e => setHistory(e.target.checked)} /> 이전 버전도 표시</label>
      <p role="status" className="library-status">{status}</p>{error && <p role="alert" className="library-error">{error}</p>}
      {loading ? <p className="library-empty">자료 목록을 읽는 중입니다.</p> : !visible.length && !error ? <p className="library-empty">{records.length ? "조건에 맞는 자료가 없습니다." : "아직 등록한 자료가 없습니다. 왼쪽에서 첫 자료를 저장하세요."}</p> : null}
      <div className="document-list">{visible.map(doc => <article className="document-card" key={doc.id}><div className="document-meta"><span>{categories[doc.category]}</span><span>V{doc.version}</span><time>{new Date(doc.createdAt).toLocaleString("ko-KR")}</time></div><h3>{doc.title}</h3>{doc.note && <p className="document-note">{doc.note}</p>}<p className="document-file">{doc.filename} · {size(doc.sizeBytes)}</p><details><summary>파일 무결성 확인값</summary><code>{doc.sha256}</code></details><a className="library-button" href={`/api/documents/${encodeURIComponent(doc.id)}`}>파일 내려받기</a></article>)}</div>
    </section>
  </div>;
}
