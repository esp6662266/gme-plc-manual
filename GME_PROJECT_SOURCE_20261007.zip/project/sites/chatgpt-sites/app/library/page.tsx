import { requireChatGPTUser, chatGPTSignOutPath } from "../chatgpt-auth";
import Library from "./library";
import "./library.css";
export const dynamic = "force-dynamic";
export default async function LibraryPage() {
  const user = await requireChatGPTUser("/library");
  return <main className="library-shell">
    <header className="library-header"><a href="/manual/index.html" className="library-brand">GME 설비 매뉴얼</a><nav><a href="/manual/manual.html">매뉴얼 읽기</a><a href={chatGPTSignOutPath("/manual/index.html")} target="_top">로그아웃</a></nav></header>
    <section className="library-intro"><p className="library-kicker">문서와 변경 이력</p><h1>자료 보관함</h1><p>매뉴얼 개정본, 점검 기록과 첨부 자료를 저장하고 다시 내려받습니다. 등록한 자료는 로그인한 계정의 보관함에 남습니다.</p><p className="library-user">로그인: {user.displayName}</p></section>
    <Library /><footer className="library-footer">기본 매뉴얼은 <a href="/manual/index.html#downloads">문서 파일과 참조 목록</a>에서 열 수 있습니다. 자료 보관은 설비 프로그램이나 설정을 변경하지 않습니다.</footer>
  </main>;
}
