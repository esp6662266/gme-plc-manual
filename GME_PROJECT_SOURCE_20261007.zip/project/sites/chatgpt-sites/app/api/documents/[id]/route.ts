import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
export const dynamic = "force-dynamic";
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "로그인이 필요합니다." }, { status: 401 });
  if (!env.DB || !env.BUCKET) return Response.json({ error: "서버 저장소가 연결되지 않았습니다." }, { status: 503 });
  const { id } = await params;
  const doc = await env.DB.prepare("SELECT filename, object_key AS objectKey FROM documents WHERE id = ? AND owner_id = ?").bind(id, user.userId).first<{ filename: string; objectKey: string }>();
  if (!doc) return Response.json({ error: "자료를 찾을 수 없습니다." }, { status: 404 });
  const object = await env.BUCKET.get(doc.objectKey);
  if (!object) return Response.json({ error: "파일을 찾을 수 없습니다." }, { status: 404 });
  return new Response(object.body, { headers: {
    "Content-Type": "application/octet-stream",
    "Content-Disposition": `attachment; filename="download"; filename*=UTF-8''${encodeURIComponent(doc.filename).replace(/'/g, "%27")}`,
    "Content-Length": String(object.size), "Cache-Control": "private, no-store",
    "X-Content-Type-Options": "nosniff", "Content-Security-Policy": "sandbox; default-src 'none'",
  } });
}
