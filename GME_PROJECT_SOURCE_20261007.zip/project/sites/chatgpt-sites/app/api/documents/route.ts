import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
export const dynamic = "force-dynamic";
const maxBytes = 25 * 1024 * 1024;
const categories = new Set(["manual", "reference", "report", "backup", "other"]);
const extensions = new Set(["pdf", "md", "txt", "csv", "json", "png", "jpg", "jpeg", "webp", "zip", "zap18", "ap18"]);
const json = (body: unknown, status = 200) => Response.json(body, { status, headers: { "Cache-Control": "private, no-store" } });
export async function GET() {
  const user = await getChatGPTUser();
  if (!user) return json({ error: "로그인이 필요합니다." }, 401);
  if (!env.DB || !env.BUCKET) return json({ error: "서버 저장소가 연결되지 않았습니다." }, 503);
  try {
    const records = await env.DB.prepare(`SELECT id, family_id AS familyId, version, title, category, note,
      filename, content_type AS contentType, size_bytes AS sizeBytes, sha256, created_at AS createdAt
      FROM documents WHERE owner_id = ? ORDER BY created_at DESC, version DESC`).bind(user.userId).all();
    return json({ documents: records.results });
  } catch { return json({ error: "자료 목록을 읽지 못했습니다. 다시 시도해 주세요." }, 500); }
}
export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: "로그인이 필요합니다." }, 401);
  const origin = request.headers.get("origin");
  if ((origin && origin !== new URL(request.url).origin) || request.headers.get("sec-fetch-site") === "cross-site") return json({ error: "이 홈페이지에서 자료를 등록해 주세요." }, 403);
  if (!env.DB || !env.BUCKET) return json({ error: "서버 저장소가 연결되지 않았습니다." }, 503);
  const db = env.DB, bucket = env.BUCKET;
  if (Number(request.headers.get("content-length") || 0) > maxBytes + 1024 * 1024) return json({ error: "파일은 25MB 이하여야 합니다." }, 413);
  let key: string | undefined;
  try {
    const form = await request.formData();
    const file = form.get("file");
    const title = String(form.get("title") || "").trim();
    const category = String(form.get("category") || "other");
    const note = String(form.get("note") || "").trim();
    const previousId = String(form.get("previousId") || "");
    if (!title || title.length > 120 || note.length > 2000 || !categories.has(category)) return json({ error: "제목·분류·변경 내용을 확인해 주세요." }, 400);
    if (!(file instanceof File) || file.size === 0) return json({ error: "저장할 파일을 선택해 주세요." }, 400);
    if (file.size > maxBytes) return json({ error: "파일은 25MB 이하여야 합니다." }, 413);
    const filename = file.name.split(/[\\/]/).pop()!.replace(/[\x00-\x1f\x7f]/g, "").slice(0, 200);
    if (!extensions.has(filename.split(".").pop()!.toLowerCase())) return json({ error: "지원하는 문서·그림·백업 파일을 선택해 주세요." }, 400);
    const id = crypto.randomUUID(); let familyId = id, version = 1;
    if (previousId) {
      const prior = await db.prepare("SELECT family_id AS familyId FROM documents WHERE id = ? AND owner_id = ?").bind(previousId, user.userId).first<{familyId: string}>();
      if (!prior) return json({ error: "이전 자료를 찾을 수 없습니다." }, 404);
      familyId = prior.familyId;
      const last = await db.prepare("SELECT MAX(version) AS version FROM documents WHERE owner_id = ? AND family_id = ?").bind(user.userId, familyId).first<{version: number}>();
      version = (last?.version || 0) + 1;
    }
    const bytes = await file.arrayBuffer();
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    const sha256 = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
    key = `documents/${user.userId}/${id}`;
    const contentType = file.type || "application/octet-stream";
    await bucket.put(key, bytes, { httpMetadata: { contentType }, customMetadata: { sha256 } });
    await db.prepare(`INSERT INTO documents (id, owner_id, family_id, version, title, category, note,
      filename, content_type, size_bytes, sha256, object_key, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(id, user.userId, familyId, version, title, category, note, filename, contentType, file.size, sha256, key, new Date().toISOString()).run();
    return json({ id, version, message: "서버에 저장했습니다." }, 201);
  } catch (error) {
    if (key) await bucket.delete(key).catch(() => {});
    if (error instanceof Error && error.message.includes("UNIQUE constraint")) return json({ error: "다른 창에서 개정본이 저장되었습니다. 목록을 새로 읽고 다시 등록해 주세요." }, 409);
    return json({ error: "저장하지 못했습니다. 파일과 연결 상태를 확인한 뒤 다시 시도해 주세요." }, 500);
  }
}
