import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GME HMI · PLC 기술 매뉴얼",
  description: "GME 설비의 운전 구조, 장애 점검, 백업과 단계적 개선을 위한 매뉴얼 및 자료 보관함",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <body className="antialiased">{children}</body>
    </html>
  );
}
