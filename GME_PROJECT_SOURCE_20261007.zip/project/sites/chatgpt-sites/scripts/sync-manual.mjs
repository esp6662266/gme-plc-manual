import fs from "node:fs";
import path from "node:path";
const source = path.resolve(process.argv[2] || "../../outputs/GME_manual_20261007");
const target = path.resolve("public/manual");
fs.mkdirSync(target, { recursive: true });
const files = ["index.html", "manual.html", "manual.md", "site.css", "site.js", "GME_HMI_PLC_manual.pdf", "README.md", "CHANGELOG.md", "PLC_communication_check_20261007.md", "홈페이지_저장구성_확인.md", "배포_상태_안내.md"];
for (const file of files) if (fs.existsSync(path.join(source, file))) fs.copyFileSync(path.join(source, file), path.join(target, file));
for (const folder of ["assets", "references"]) fs.cpSync(path.join(source, folder), path.join(target, folder), { recursive: true });
for (const file of ["index.html", "manual.html"]) {
  const filePath = path.join(target, file);
  let html = fs.readFileSync(filePath, "utf8");
  html = html.replace('</nav>', '<a href="/library">자료 보관함</a></nav>');
  html = html.replace('이 홈페이지는 저장된 문서를 보여주는 파일이며 설비의 실시간 상태를 표시하거나 제어하지 않습니다.', '이 홈페이지는 기술 문서와 자료 보관함을 제공하며 설비의 실시간 상태를 표시하거나 제어하지 않습니다.');
  fs.writeFileSync(filePath, html);
}
console.log("Manual files synchronized.");
